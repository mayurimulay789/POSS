import { FIXED_PERMISSIONS } from './fixedPermissions';

// Common sidebar items structure
export const SIDEBAR_ITEMS = {
  dashboard: {
    path: '/dashboard',
    label: 'Dashboard',
    icon: '📊',
    permission: FIXED_PERMISSIONS.ORDER_MANAGEMENT, // Basic permission for dashboard
  },
  hotelImages: {
    path: '/hotel-images',
    label: 'Hotel Images',
    icon: '🖼️',
    permission: FIXED_PERMISSIONS.HOTEL_IMAGES,
  },
  orders: {
    path: '/orders',
    label: 'Order Management',
    icon: '📝',
    permission: FIXED_PERMISSIONS.ORDER_MANAGEMENT,
  },
  menu: {
    path: '/menu',
    label: 'Menu Management',
    icon: '📋',
    permission: FIXED_PERMISSIONS.MENU_MANAGEMENT,
    subItems: [
      {
        path: '/menu/add',
        label: 'Add Menu',
        icon: '➕',
        permission: FIXED_PERMISSIONS.MENU_MANAGEMENT,
      },
      {
        path: '/menu/list',
        label: 'Menu List',
        icon: '📝',
        permission: FIXED_PERMISSIONS.MENU_MANAGEMENT,
      },
    ]
  },
  billing: {
    path: '/billing',
    label: 'Billing Management',
    icon: '💰',
    permission: FIXED_PERMISSIONS.BILLING_MANAGEMENT,
  },
  spaces: {
    path: '/spaces',
    label: 'Space Management',
    icon: '🪑',
    permission: FIXED_PERMISSIONS.SPACE_MANAGEMENT,
  },
  tasks: {
    path: '/tasks',
    label: 'Task Management',
    icon: '✅',
    permission: FIXED_PERMISSIONS.TASK_MANAGEMENT,
  },
  expenses: {
    path: '/expenses',
    label: 'Expense Management',
    icon: '💸',
    permission: FIXED_PERMISSIONS.EXPENSE_MANAGEMENT,
  },
  // reports: {
  //   path: '/reports',
  //   label: 'Reports & Analytics',
  //   icon: '📈',
  //   permission: FIXED_PERMISSIONS.REPORTS_ANALYTICS,
  // },
  employees: {
    path: '/employees',
    label: 'Employee Management',
    icon: '👥',
    permission: FIXED_PERMISSIONS.EMPLOYEE_MANAGEMENT,
  },
  customers: {
    path: '/customers',
    label: 'Customer Management',
    icon: '🧑‍🤝‍🧑',
    permission: FIXED_PERMISSIONS.CUSTOMER_MANAGEMENT,
  },
  charges: {
    path: '/charges',
    label: 'Charges Management',
    icon: '💲',
    permission: FIXED_PERMISSIONS.CHARGES_MANAGEMENT,
  },
  attendance: {
    path: '/attendance-dashboard',
    label: 'Attendance Management',
    icon: '🕒',
    permission: FIXED_PERMISSIONS.ATTENDANCE_MANAGEMENT,
  },
  permissions: {
    path: '/permission-management',
    label: 'Permission Management',
    icon: '🔐',
    permission: FIXED_PERMISSIONS.EMPLOYEE_MANAGEMENT, // Only for merchant
  },

  landingPageManagement: {
    path: '/landing-page',
    label: 'Landing Page Management',
    icon: '🌐',
    permission: FIXED_PERMISSIONS.LANDING_PAGE_MANAGEMENT,
    subItems: [
      {
        path: '/about-us-management',
        label: 'About Us',
        icon: 'ℹ️',
        permission: FIXED_PERMISSIONS.ABOUT_US_MANAGEMENT,
      },
      {
        path: '/contact-us-management',
        label: 'Contact Us',
        icon: '📞',
        permission: FIXED_PERMISSIONS.CONTACT_US_MANAGEMENT,
      },
      {
        path: '/welcome-section-management',
        label: 'Welcome Section',
        icon: '🏨',
        permission: FIXED_PERMISSIONS.WELCOME_SECTION_MANAGEMENT,
      },
      {
        path: '/cuisine-gallery-management',
        label: 'Cuisine Gallery',
        icon: '🍽️',
        permission: FIXED_PERMISSIONS.CUISINE_GALLERY_MANAGEMENT,
      },
      {
        path: '/logo-management',
        label: 'Logo Management',
        icon: '🖼️',
        permission: FIXED_PERMISSIONS.LOGO_MANAGEMENT,
      }
      ,{
        path: '/footer-management',
        label: 'Footer Management',
        icon: '🔻',
        permission: FIXED_PERMISSIONS.FOOTER_MANAGEMENT,
      }
    ]
  }
};

// Get sidebar items for a specific role based on their permissions
export const getSidebarItemsForRole = (rolePermissions = []) => {
  const items = Object.values(SIDEBAR_ITEMS)
    .filter(item =>
      // Include if no permission required, else check role permissions
      !item.permission || rolePermissions.includes(item.permission)
    )
    .map(item => {
      // If item has subitems, filter those as well
      if (item.subItems && item.subItems.length > 0) {
        const filteredSubItems = item.subItems.filter(subItem =>
          !subItem.permission || rolePermissions.includes(subItem.permission)
        );
        return {
          ...item,
          subItems: filteredSubItems
        };
      }
      return item;
    });
  
  console.log('getSidebarItemsForRole - Filtered items:', items.map(i => i.label));
  return items;
};

// Group items for better organization
export const GROUPED_SIDEBAR_ITEMS = {
  main: ['dashboard'],
  operations: ['orders', 'menu', 'billing'],
  management: ['hotelImages', 'spaces', 'tasks', 'expenses','customers'],
  // analytics: ['reports'],
  administration: ['employees', 'permissions', 'charges','attendance','landingPageManagement'],
};