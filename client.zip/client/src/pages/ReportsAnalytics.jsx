import React from 'react'

const ReportsAnalytics = () => {
  return (
    <div>ReportsAnalytics</div>
  )
}

export default ReportsAnalytics