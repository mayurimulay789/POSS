import React from 'react';
import FooterManagement from '../components/merchant/FooterManagement/FooterManagement';

const FooterManagementPage = () => {
  return <FooterManagement />;
};

export default FooterManagementPage;
