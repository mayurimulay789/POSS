// Barrel file for easy imports
export { default as CustomerStats } from './CustomerStats';
export { default as CustomerHeader } from './CustomerHeader';
export { default as CustomerTable } from './CustomerTable';
export * from './CustomerModals';